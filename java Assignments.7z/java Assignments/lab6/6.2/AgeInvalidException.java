package com.cg.lab6;

public class AgeInvalidException extends Exception{
		public AgeInvalidException() {
			super();
			
		}

		public AgeInvalidException(String arg0) {
			super(arg0);
			
		}
}
