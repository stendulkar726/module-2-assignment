package com.cg.lab3;

import java.util.*;

public class AssgTwoPossitiveStr {
	public boolean positiveString(String str) {
		boolean fl = false;
		char temp[] = str.toCharArray();
		char temp1[] = str.toCharArray();
		Arrays.sort(temp);
		if (Arrays.equals(temp, temp1)) {
			fl = true;
		}
		return fl;
	}

	public static void main(String[] args) {

		AssgTwoPossitiveStr ap = new AssgTwoPossitiveStr();
		System.out.println("Enter a String:");
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		boolean out = ap.positiveString(str);
		if (out == true) {

			System.out.println("String is positive");
		}
		if (out == false) {

			System.out.println("String in negative");
		}
		sc.close();
	}

}
