package com.cg.lab13;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CopyDataThread extends Thread {

	public void threadDemo() {

	/*	File dr = new File("mydir");
		File f1 = new File("dir", "source.txt");
		File f2 = new File("mydir", "target.txt");

		try {
			if (!dr.exists()) {
				dr.mkdir();
				if (!f1.exists()) {
					f1.createNewFile();
					if (!f2.exists())
						f2.createNewFile();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		try {
			FileInputStream fin = new FileInputStream("source.txt");
			FileOutputStream fout = new FileOutputStream("target.txt", true);
			int i=0,j=0;
			while((j = fin.read() )!= -1)
			{
				i++;
				fout.write(j);
				if(i % 10 == 0)
				{
					try {
						Thread.sleep(5000);
						System.out.println("10 characters are copied");
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void run() {
		threadDemo();
	}
}
