package com.cg.lab7_3;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeServiceImpl hash = new EmployeeServiceImpl();
		HashMap<String, Employee> hash1 = new HashMap<String, Employee>();
		int i = 0;

		while (true) {
			System.out.println(
					"\n\n\n 1. Add Employee Details. \n 2. Get Employee Details Based on Insurance Scheme. \n 3. Remove a Employee Record. \n 4. Sort Employee Records.  \n 5. exit. \n");
			System.out.println();
			i = sc.nextInt();
			switch (i) {

			case 1:
				System.out.println("Enter no of employees to enter :");
				int j = sc.nextInt();

				for (int k = 0; k < j; k++) {
					Employee emp = new Employee();
					System.out.println("Enter Name :");
					emp.setName(sc.next());
					System.out.println("Enter Id :");
					emp.setId(sc.nextInt());
					System.out.println("Enter Salary :");
					emp.setSalary(sc.nextDouble());
					emp.setDesignation();
					emp.setInsuranceScheme();
					hash1.put(emp.getName(), emp);
				}
				// hash.showEmployee(hash1);
				break;

			case 2:
				System.out.println();
				System.out.println(
						"Enter  \n'A' for Scheme A \n 'B' for Schem B \n 'C' for Scheme C \n 'N' for No Scheme");
				String ins = sc.next();
				String send = "";
				if (ins.equals("A")) {
					send = "Scheme A";
				} else if (ins.equals("B")) {
					send = "Scheme B";
				} else if (ins.equals("C")) {
					send = "Scheme C";
				} else if (ins.equals("N")) {
					send = "No Scheme";
				} else {
					System.out.println("Please enter right input....");
				}
				hash.displayEmployeeBasedInsurence(send, hash1);
				System.out.println();
				break;
			case 3:
				System.out.println();
				System.out.println("Enter Employee ID to Remove Records -: ");
				int ide = sc.nextInt();
				if (hash.deleteEmployee(ide, hash1) == true)
					System.out.println("Record Removed..");
				else
					System.out.println("Record not present in the list.");
				break;
			case 4:
				hash.sortOnSalary(hash1);
				break;
			case 5:
				return;
			default:
				System.out.println("Please Select options from below list.....");
				System.out.println();
				break;

			}

		}

	}

}
