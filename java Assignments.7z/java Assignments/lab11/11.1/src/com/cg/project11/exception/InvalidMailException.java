package com.cg.project11.exception;

public class InvalidMailException extends Exception {

	public InvalidMailException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidMailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
