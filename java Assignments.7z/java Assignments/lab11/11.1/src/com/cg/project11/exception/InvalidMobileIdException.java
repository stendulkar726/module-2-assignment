package com.cg.project11.exception;

public class InvalidMobileIdException extends Exception {

	public InvalidMobileIdException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidMobileIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
