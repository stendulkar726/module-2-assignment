package com.cg.project11.validate;

public class ValidateMobiles {

	boolean val = false;

	public boolean isMobileId(String mobileId) {
		val = false;
		if (mobileId.length() == 4) {
			int i = 0;
			while (i < 4) {
				if (Character.isDigit(mobileId.charAt(i))) {
					val = true;
				} else {
					val = false;
				}
			}
		}
		return val;
	}

	public boolean isMobName(String mobName) {
		val = false;
		if (mobName.length() <= 20) {
			if (Character.isUpperCase(mobName.charAt(0))) {
				val = true;
			} else {
				val = false;
			}
		}
		return val;
	}

	public boolean isPrice(String price) {

		val = false;
		int l = price.length();
		int d1 = price.indexOf('.');
		int d2 = price.lastIndexOf('.');

		if (d1 == d2) {
			String[] s = price.split(".");
			if (s[1].length() == 2) {
				val = true;
			}
		}
		return val;
	}

	public boolean isQuantity(String quantity) {
		val = false;
		int i = Integer.parseInt(quantity);
		if (i > 0 && i <= 100) {
			val = true;
		}

		return val;
	}

}
