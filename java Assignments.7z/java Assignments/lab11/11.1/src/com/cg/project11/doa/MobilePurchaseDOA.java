package com.cg.project11.doa;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Properties;

import com.cg.project11.models.PurchaseDetails;
import com.cg.project11.validate.ValidatePurchaseDetails;
import com.cg.project11.view.GetInputForPurchase;

public class MobilePurchaseDOA {

	Connection con = null;
	/*
	 * String driverName = "oracle.jdbc.OracleDriver"; String url =
	 * "jdbc:oracle:thin:@localhost:1521:XE"; String user = "yash";// depends on
	 * system user String pass = "yash";// depends on system
	 */
	String driver = null;
	String url = null;
	String user = null;
	String pass = null;

	public Connection getCon() {
		try (InputStream input = new FileInputStream("Resources/db.properties")) {

			Properties prop = new Properties();

			// load a properties file
			prop.load(input);

			// get the property value and print it out
			driver = prop.getProperty("driverName");
			url = prop.getProperty("url");
			user = prop.getProperty("user");
			pass = prop.getProperty("pass");

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		try {

			Class.forName(driver);

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			con = DriverManager.getConnection(url, user, pass);
			// System.out.println("connection has been established.....");

		} catch (SQLException e2) {
			e2.printStackTrace();
		}

		return con;
	}

	public void showMobiles() {
		Connection con = getCon();
		ResultSet rs = null;
		Statement stat = null;
		String query = "select * from mobiles";
		try {
			stat = con.createStatement();
			rs = stat.executeQuery(query);
			System.out.println(" \nMobile Id \t\t Mobile Name \t\t Price \t\t\t Quantity\n");
			// String str = String.format("\n %6d %20s %20s %20s");
			while (rs.next()) {
				System.out.printf(rs.getInt(1) + " \t\t " + rs.getString(2) + " \t\t" + rs.getDouble(3) + " \t\t\t "
						+ rs.getString(4) + " \n");
			}
			System.out.println();
			rs.close();
			stat.close();
			con.close();
		} catch (SQLException e) {
			e.getErrorCode();
		}
	}

	public void deleteMobile(int id) {
		String str = "delete from mobiles where mobileid = ?";
		con = getCon();
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(str);

		} catch (SQLException e) {
			System.out.println("unable to create statement");
		}

		try {
			stat.setInt(1, id);
			boolean r = stat.execute();
			if (r)
				System.out.println("record not deleted");
			else
				System.out.println("record deleted");
		} catch (SQLException e) {
			// System.out.println(e.getErrorCode());
			e.printStackTrace();
		}
		try {
			stat.close();
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getErrorCode());
		}
	}

	public boolean searchOnPrice(double lower, double higher) {
		con = getCon();
		PreparedStatement pr = null;
		Boolean ret = false;
		String str = "select * from mobiles where price between ? and ?";
		if(lower < higher && (higher - lower >= 1000) && higher > 0 && lower > 0)
		{
			ret = true;
		try {
			pr = con.prepareStatement(str);
			pr.setDouble(1, lower);
			pr.setDouble(2, higher);
			ResultSet rs = pr.executeQuery();
			System.out.println(" \nMobile Id \t\t Mobile Name \t\t Price \t\t\t Quantity\n");
			// String str = String.format("\n %6d %20s %20s %20s");
			while (rs.next()) {
				System.out.printf(rs.getInt(1) + " \t\t " + rs.getString(2) + " \t\t" + rs.getDouble(3) + " \t\t\t "
						+ rs.getString(4) + " \n");
			}
			System.out.println();
		} catch (SQLException e) {
			System.out.println(e.getErrorCode());
			System.out.println(e.getSQLState());
		}
		}
		else
		{
			System.out.println("Please check entered values (minimum difference must be 1000 rupee.  )");
		}
		return ret;
	}

	public int getPurchaseId() {
		Connection con = getCon();
		ResultSet rs = null;
		Statement stat = null;
		int seq = 0;
		String query = "select newperchaseid.nextval from dual";
		try {
			stat = con.createStatement();
			rs = stat.executeQuery(query);
			rs.next();
			seq = rs.getInt(1);
			// System.out.println(rs.getInt(1));
			rs.close();
			stat.close();
			con.close();
		} catch (SQLException e) {
			e.getErrorCode();
		}
		return seq;
	}

	/*
	 * public Mobiles getRec(int id) { Mobiles pde = new Mobiles(); Connection
	 * con = getCon(); ResultSet rs = null; Statement stat = null; String query
	 * = "select * from mobiles where mobileid =" + id; try { stat =
	 * con.createStatement(); rs = stat.executeQuery(query);
	 * 
	 * pde.setMobileId(rs.getInt(1)); pde.setMobName(rs.getString(2));
	 * pde.setPrice(rs.getDouble(3)); pde.setQuantity(rs.getString(4));
	 * 
	 * rs.close(); stat.close(); con.close(); } catch (SQLException e) {
	 * e.getErrorCode(); } return pde; }
	 */
	public boolean addPerchaseRec(PurchaseDetails pd, int quantity) {
		ValidatePurchaseDetails vp = new ValidatePurchaseDetails();
		boolean ok = false;
		pd.setPurchaseId(getPurchaseId());
		pd.setPerchaseDate(Date.valueOf(LocalDate.now()));
		/*
		 * System.out.println(b1); System.out.println(b2);
		 * System.out.println(b3); System.out.println(b4);
		 */
		int count = 4;
		GetInputForPurchase gi = new GetInputForPurchase();

		// System.out.println(pd);
		boolean purchased = false;
		boolean quant = quantityCheck(Integer.parseInt(pd.getMobId()), quantity);
		System.out.println(quant);
		if (count == 4 && quant == true && quantity > 0) {
			ok = true;
			String str = "insert into purchasedetails values(?,?,?,?,?,?)";
			con = getCon();
			PreparedStatement stat = null;
			try {
				stat = con.prepareStatement(str);

			} catch (SQLException e) {
				System.out.println("unable to create statement");
			}
			Date date = new Date(0000 - 00 - 00);
			// SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
			// String f = format.format(pd.getPerchaseDate());
			try {
				stat.setInt(1, pd.getPurchaseId());
				stat.setString(2, pd.getCustName());
				stat.setString(3, pd.getMailId());
				stat.setString(4, pd.getPhoneNo());
				stat.setDate(5, pd.getPerchaseDate());
				stat.setInt(6, Integer.parseInt(pd.getMobId()));
				boolean r = stat.execute();
				if (r)
					System.out.println("purchase details are not inserted");
				else {
					System.out.println("purchase record inserted");
					purchased = true;
				}
			} catch (SQLException e) {
				// System.out.println(e.getErrorCode());
				e.printStackTrace();
			}
			try {
				stat.close();
				con.close();
				if (purchased)
					updateQuantity(quantity, Integer.parseInt(pd.getMobId()));
			} catch (SQLException e) {
				System.out.println(e.getErrorCode());
			}
		}
		return ok;
		// not complete
	}

	public boolean quantityCheck(int ide, int quant) {
		boolean out = false;
		Connection con = getCon();
		ResultSet rs = null;
		PreparedStatement stat = null;
		String query = "select quantity from mobiles where mobileid =?";
		try {
			stat = con.prepareStatement(query);
			stat.setInt(1, ide);
			rs = stat.executeQuery();
			rs.next();
			int qua = rs.getInt(1);

			// System.out.println(qua);
			if (qua < quant) {
				out = false;
				System.out.println("We are currencly Out of stock for this item....");
			} else
				out = true;
			rs.close();
			stat.close();
			con.close();
		} catch (SQLException e) {
			e.getErrorCode();
		}
		// System.out.println(out);
		return out;
	}

	public boolean updateQuantity(int quantity, int mobid) {
		String str = "update mobiles set quantity = quantity - ? where mobileid = ?";
		// System.out.println(str);
		con = getCon();
		PreparedStatement stt = null;
		boolean rs = true;
		try {
			stt = con.prepareStatement(str);
			stt.setInt(1, quantity);
			stt.setInt(2, mobid);
			rs = stt.execute();
			/*
			 * if (rs) // System.out.println("not updated"); else
			 * //System.out.println("updated");
			 */
		} catch (SQLException e) {
			System.out.println(e);
		}

		try {
			stt.close();
			con.close();
		} catch (Exception e) {
		}
		return !rs;
	}
}
