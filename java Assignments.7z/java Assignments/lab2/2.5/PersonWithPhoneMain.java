package com.cg.lab2;

import com.cg.lab2.FirstEnum.*;

public class PersonWithPhoneMain {

	public static void main(String[] args) {

		PersonWithPhone pr = new PersonWithPhone("Thiago", "Alkantara", Gender.M, 858495);
		pr.setphone(9076758465L);
		pr.display();
		
		PersonWithPhone pm = new PersonWithPhone("Divya", "Bharati", Gender.F, 858495);
		pm.setphone(8977635223L);
		pm.display();

	}

}
