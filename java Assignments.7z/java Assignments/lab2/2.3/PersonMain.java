package com.cg.lab2;

public class PersonMain {

	public static void main(String[] args) {
		Person pr =  new Person("Thiago","Alkantara",'M');
		
		System.out.println("Person Details:");
		System.out.println("________________________________");
		System.out.println();
		System.out.println("First Name: "+pr.firstName);
		System.out.println("Last Name: "+pr.lastName);
		System.out.println("Gender: "+pr.gender);
	}

}
