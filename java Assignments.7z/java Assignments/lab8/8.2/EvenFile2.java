package com.cg.lab8;
import java.util.*;
import java.io.*;
public class EvenFile2 {

	public static void main(String[] args) {
		try {
			File fl = new File("numbers.txt");
			Scanner sc = new Scanner(fl);
			String str = sc.nextLine();
			int[] arr = new int[str.length()];
			int inc = 0;
			for(int i = 0;i<str.length();i++)
			{
				char c = str.charAt(i);
				if(c != ',')
				{
					int temp = Character.getNumericValue(c);
					if(temp % 2 == 0 && temp !=0)
					arr[inc++] = temp ;
				}
			}
			System.out.println("Even NO:");
			
			for(int j=0;j<inc;j++)
			{
				System.out.println(arr[j]);
			}
			
			
		} catch (FileNotFoundException e) {
			System.out.println("file not found");
		} 
	}

}
