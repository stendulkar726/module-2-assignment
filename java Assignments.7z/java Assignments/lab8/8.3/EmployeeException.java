package com.cg.lab8.p8_3;

public class EmployeeException extends Exception {

	public EmployeeException() {
		super();
	}

	public EmployeeException(String arg0) {
		super(arg0);
	}

}
