package com.cpg.lab9.q2;

public class Insuffecientsal extends Exception {

	public Insuffecientsal() {
		super();
	}

	public Insuffecientsal(String message) {
		super(message);
	}

}
