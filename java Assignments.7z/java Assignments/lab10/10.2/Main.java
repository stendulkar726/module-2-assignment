package com.cg.lab10;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Service s = new Service();
		String cont = "Y";
		Scanner sc = new Scanner(System.in);
		while (cont != "N" || cont != "n") {
			int i = 0;
			System.out.println("Menu");
			System.out.println(
					"\n1.Add employee details\n2.Get Details\n3.Get Schemes\n4.Remove Employes\n5.Display All\n6.Exit");
			System.out.println("\nEnter Choice : ");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				while (i != 2) {
					System.out.println("Enter employee id : ");
					int id = sc.nextInt();
					System.out.println("Enter employee name : ");
					String na = sc.next();
					System.out.println("Enter employee salary : ");
					double sal = sc.nextDouble();
					Employee e = new Employee(id, na, sal, null, null);
					s.addEmployeeDetails(e);
					System.out.println("\nEnter another (Y-1/N-2) : ");
					i = sc.nextInt();
				}
				break;
			case 2:
				while (i != 2) {
					System.out.println("\nEnter employee id : ");
					// Employee10_2 e = new Employee10_2();
					int id = sc.nextInt();
					System.out.println("Employee datails\n");
					s.getEmployeeDetails(id);
					System.out.println("\nEnter another (Y-1/N-2) : ");
					i = sc.nextInt();
				}
				break;
			case 3:
				while (i != 2) {
					System.out.println("\nEnter Scheme : ");
					// Employee10_2 e = new Employee10_2();
					String sch = sc.next();
					System.out.println("\nEmployee datails\n");
					s.getInsuranceScheme(sch);
					System.out.println("\nEnter another (Y-1/N-2) : ");
					i = sc.nextInt();
				}
				break;
			case 4:
				while (i != 2) {
					System.out.println("\nEnter employee id to be removed : ");
					// Employee10_2 e = new Employee10_2();
					int id = sc.nextInt();
					s.RemoveEmpDetails(id);
					System.out.println("\nRemove another (Y-1/N-2) : ");
					i = sc.nextInt();
				}
				break;
			case 5:
				s.DisplayAll();
				break;
			case 6:
				return;
			default:
				System.out.println("\nWrong Choice");
				break;
			}
			System.out.println("\nDo you want to continue to Menu (Y/N)");
			cont = sc.next();
		}
		sc.close();

	}
}